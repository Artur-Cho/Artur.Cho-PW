var nome = "Soffia Luanny dos Anjos Sales";
var nome2 = prompt("Digite seu nome: ");
var idade = parseInt (prompt("Digite sua idade: "));

console.log("Seu Nome é: "+ nome);
console.log("Sa idade é: "+ idade);
alert("Seu nome é: " + nome2);
alert("Sua idade é: "+ idade);