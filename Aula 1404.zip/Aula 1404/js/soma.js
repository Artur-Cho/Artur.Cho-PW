var num1 = parseInt(prompt("Digite o primeiro número: "));
var num2 = parseInt(prompt("Digite o segundo número: "));
var soma = num1 + num2;
console.log("Digite o primeiro número: "+ num1);
console.log("Digite o primeiro número: "+ num2);
console.log("A soma dos dois números são: "+ soma)
alert("A soma dos dois números são: "+ soma);